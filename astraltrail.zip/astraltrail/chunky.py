import numpy as np


class Block:
    def __init__(self, **kwargs):
        self.material = kwargs.get('material', 0)
        self.tile = kwargs.get('tile', 1.00)
        self.visibility_index = [0, 0, 0, 0, 0, 0]

        self.parent_section:Section = kwargs.get('parent')
        self.local_address = kwargs.get('local_address')
        self.pos = None
        self.yaw = 0.0
        self.pitch = 0.0
        self.roll = 0.0

        self.global_address = self.parent_section.global_address + self.local_address

        parsed_address = self.global_address.split('-')

        glb_x = int(self.global_address[0]) * 16 + int(self.global_address[3])
        glb_y = int(self.global_address[2]) * 16 + int(self.global_address[4])
        glb_z = int(self.global_address[1]) * 16 + int(self.global_address[5])

        self.pos= np.array([glb_x, glb_y, glb_z], dtype=np.float32)

    def get_indice_list(self):
        pass


class Section:
    def __init__(self, **kwargs):
        self.parent_chunk:Chunk = kwargs.get('parent')
        self.local_address = kwargs.get('address')
        self.frame = kwargs.get('frame', 'abs')
        self.pos = kwargs.get('pos', np.array(0.0, 0.0, 0.0), dtype=np.float32)
        self.yaw = kwargs.get('yaw', 0.0)
        self.pitch = kwargs.get('pitch', 0.0)
        self.roll = kwargs.get('roll', 0.0)
        self.size = kwargs.get('size', 'large')

        self.global_address = self.parent_chunk.global_address + self.local_address

        self.section_map:dict[tuple[int, int, int], Block] = {}

        self.initiate_section()

    def initiate_section(self):
        for y in range(16):
            for x in range(16):
                for z in range(16):
                    address = (x, y, z)
                    self.section_map[address] = Block(parent=self, local_address=(x, y, z))

    def update_visibility(self):
        for block in self.section_map.values():
            block.visibility_index = update_block_visibility(block.global_address)


class Chunk:
    def __init__(self, **kwargs):
        self.parent_world:World = kwargs.get('parent', World())
        self.local_address = kwargs.get('address')
        self.frame = kwargs.get('frame', 'abs')
        self.pos = kwargs.get('pos', np.array(0.0, 0.0, 0.0), dtype=np.float32)
        self.yaw = kwargs.get('yaw', 0.0)
        self.pitch = kwargs.get('pitch', 0.0)
        self.roll = kwargs.get('roll', 0.0)
        self.size = kwargs.get('size', 'large')

        self.global_address = self.parent_world.global_address + self.local_address

        self.chunk_map = {}

        self.initiate_chunk()

    def initiate_chunk(self):
        for y in range(16):
            address = (y)
            self.chunk_map[address] = Section(parent=self, local_address=(y))  

    def update_visibility(self):
        for section in self.chunk_map.values():
            section.update_visibility()

    def get_visible_vertexes(self):
        pass


class World:
    def __init__(self, **kwargs):
        self.frame = 'abs'
        self.world_map = {}

        self.global_address = 0

        self.initiate_world()

    def initiate_world(self):
        for x in range(16):
            for z in range(16):
                address = (x, z)
                self.world_map[address] = Chunk(parent=self, local_address=(x, z))

    def update_visibility(self):
        for chunk in self.world_map.values():
            chunk.update_visiblity()



def update_block_visibility(block: Block) -> None:
    adjoining = get_adjoining_addresses(block.global_address)
    world = block.parent_section.parent_chunk.parent_world
    adjoining_visibility_key = []
    if len(adjoining) < 6:
        block.visible = True
    else:
        for i in range(len(adjoining)):
            chnk = (adjoining[i][1], adjoining[i][2])
            sect = adjoining[i][3]
            blck = (adjoining[i][4], adjoining[i][5], adjoining[i][6])
            material = world.world_map[chnk].chunk_map[sect].section_map[blck].material
            if material < 0:
                adjoining_visibility_key[i] = 1
                block.visible = True
            else:
                adjoining_visibility_key[i] = 0

    return adjoining_visibility_key

def get_adjoining_addresses(address:tuple) -> list[tuple,]:
    base = address[:4]
    bx, by, bz = address[4:]

    neighbours = []
    for dx, dy, dz in [
        (-1, 0, 0), (1, 0, 0),
        (0, -1, 0), (0, 1, 0),
        (0, 0, -1), (0, 0, 1)
    ]:
        nbx, nby, nbz = bx + dx, by + dy, bz + dz
        w, cx, cz, sy = base

        if nbx == 16:
            nbx = 0
            cx += 1
        elif nbx == -1:
            nbx = 0
            cx -= 1
        if nbz == 16:
            nbz = 0
            cz += 1
        elif nbz == -1:
            nbz = 0
            cz -= 1
        if nby == 16:
            nby = 0
            sy += 1
        elif nby == -1:
            nby = 0
            sy -= 1


    if sy not in (-1, 16):
        neighbours.append((w, cx, cz, sy, nbx, nby, nbz)) 

    return neighbours


